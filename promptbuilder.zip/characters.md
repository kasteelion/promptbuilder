### Sample Character
**Appearance:** A sample character for you to get started.
**Outfits:**
- **Base:** A default outfit.
